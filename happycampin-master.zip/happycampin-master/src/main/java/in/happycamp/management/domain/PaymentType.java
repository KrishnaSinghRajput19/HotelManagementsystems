package in.happycamp.management.domain;

/**
 * Created on November, 2017
 *
 * @author adilcan
 */
public enum PaymentType {
	CASH, CARD;
}
