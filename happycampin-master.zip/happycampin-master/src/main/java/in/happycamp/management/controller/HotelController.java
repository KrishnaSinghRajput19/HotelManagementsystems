package in.happycamp.management.controller;

/**
 * Created on November, 2017
 *
 * @author adilcan
 */
public class HotelController {

}
